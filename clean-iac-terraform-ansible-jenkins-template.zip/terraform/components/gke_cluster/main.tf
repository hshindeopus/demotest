module "gke_cluster" {
  source = "../../modules/gke_cluster"

  cluster_name = var.resource_name
  node_count   = 3
  region       = var.region
}