variable "project" {
  type = string
}

variable "region" {
  type = string
}

variable "iac_id" {
  type = string
}

variable "resource_name" {
  type = string
}